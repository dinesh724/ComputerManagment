import react from 'react';
import ManageComputer from './ManageComputer.js';
import './App.css';

function App() {
  return (
   <div className="container">
    <div className="logo"></div>
    <div className="header">Contact Management System</div>
    <div className="nav"></div>
    <div className="content">
    <ManageComputer/>
    </div>
    <div className="footer"></div>

   </div>
  );
}

export default App;
