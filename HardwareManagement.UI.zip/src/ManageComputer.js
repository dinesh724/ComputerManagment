import React,{useEffect , useState } from 'react'
import axios from 'axios'
import './ManageComputer.css';
const Graphics_URL = 'https://localhost:44349/api/graphics'
const HardDisk_URL = 'https://localhost:44349/api/harddisk'
const Port_URL = 'https://localhost:44349/api/ports'
const Power_URL = 'https://localhost:44349/api/power'
const Processor_URL = 'https://localhost:44349/api/processor'
const Ram_URL = 'https://localhost:44349/api/ram'
const Weight_URL = 'https://localhost:44349/api/weight'

const BASE_URL_ForComputers = 'https://localhost:44349/api/computer'

export default function PostForm() {
    const [graphicsOptions, setgraphics] = useState([]) 
    const [harddiskOptions, setharddisk] = useState([]) 
    const [portOptions, setport] = useState([]) 
    const [powerOptions, setpower] = useState([]) 
    const [processorOptions, setprocessor] = useState([]) 
    const [ramOptions, setram] = useState([]) 
    const [weightOptions, setweight] = useState([]) 
    const [computers, setComputers] = useState([]) 
    const [error, seterror] = useState([]) 

    const[data,setData] = useState({
        "name": "",
        "firstName": "",
        "graphicsName": "",
        "hardDiskName": "",
        "portName": "",
        "powerName": "",
        "processorName": "",
        "ramName": "",
        "weightName": "",
    })

useEffect(() => {

    fetch(Graphics_URL)
      .then(res => res.json())
      .then(data => {setgraphics(data)})
      .catch((error) => {
        console.log(error)
      });

      fetch(HardDisk_URL)
      .then(res => res.json())
      .then(data => {setharddisk(data)})
      .catch((error) => {
        console.log(error)
      });

      fetch(Port_URL)
      .then(res => res.json())
      .then(data => {setport(data)})
      .catch((error) => {
        console.log(error)
      });

      fetch(Power_URL)
      .then(res => res.json())
      .then(data => {setpower(data)})
      .catch((error) => {
        console.log(error)
      });

      fetch(Processor_URL)
      .then(res => res.json())
      .then(data => {setprocessor(data)})
      .catch((error) => {
        console.log(error)
      });

      fetch(Ram_URL)
      .then(res => res.json())
      .then(data => {setram(data)})
      .catch((error) => {
        console.log(error)
      });

      fetch(Weight_URL)
      .then(res => res.json())
      .then(data => {setweight(data)})
      .catch((error) => {
        console.log(error)
      });

      fetch(BASE_URL_ForComputers)
      .then(res => res.json())
      .then(data => {setComputers(data)})
      .catch((error) => {
        console.log(error)
      });

  }, [])


 function Submit(e){
    e.preventDefault();
    
}



function handle(e)
{
    const newdata = {...data}
   
    newdata[e.target.id] = e.target.value
    //setData(newdata)
}

    return (
        <div >
                <form className="FormStyle" onSubmit={(e) => Submit(e)}>
                    
                    <label id="graphics">Graphics </label>
                    <select  onChange={(e) => handle(e)} id="graphics">
                    <option key="Select" value="Select" >Select</option>
                    {graphicsOptions.map((option) => (
                    <option key={option.graphicName} value={option.graphicName}>{option.graphicName}</option>
                    ))}
                    </select>

                    <label id="harddisk">Hard Disk </label>
                    <select  onChange={(e) => handle(e)} id="harddisk">
                    <option key="Select" value="Select" >Select</option>
                    {harddiskOptions.map((option) => (
                    <option key={option.hardDiskName} value={option.hardDiskName}>{option.hardDiskName}</option>
                    ))}
                    </select>

                    <label id="port">Port </label>
                    <select  onChange={(e) => handle(e)} id="port">
                    <option key="Select" value="Select" >Select</option>
                    {portOptions.map((option) => (
                    <option key={option.portName} value={option.portName}>{option.portName}</option>
                    ))}
                    </select>

                    <label id="power">Power </label>
                    <select  onChange={(e) => handle(e)} id="power">
                    <option key="Select" value="Select" >Select</option>
                    {powerOptions.map((option) => (
                    <option key={option.powerInfo} value={option.powerInfo}>{option.powerInfo}</option>
                    ))}
                    </select>

                    <label id="processor">Processor </label>
                    <select  onChange={(e) => handle(e)} id="processor">
                    <option key="Select" value="Select" >Select</option>
                    {processorOptions.map((option) => (
                    <option key={option.processorName} value={option.processorName}>{option.processorName}</option>
                    ))}
                    </select>

                    <label id="ram">Ram </label>
                    <select  onChange={(e) => handle(e)} id="ram">
                    <option key="Select" value="Select" >Select</option>
                    {ramOptions.map((option) => (
                    <option key={option.ramName} value={option.ramName}>{option.ramName}</option>
                    ))}
                    </select>

                    <label id="weight">Weight </label>
                    <select  onChange={(e) => handle(e)} id="weight">
                    <option key="Select" value="Select" >Select</option>
                    {weightOptions.map((option) => (
                    <option key={option.weightDetail} value={option.weightDetail}>{option.weightDetail}</option>
                    ))}
                    </select>
                    
                            <button className="btn btn-default">Submit</button>
                </form>


                <table>
                    <tbody>
                <tr>
                    <th>Computer Name</th>
                    <th>Graphics</th>
                    <th>HardDisk</th>
                    <th>Port</th>
                    <th>Power</th>
                    <th>Processor</th>
                    <th>Ram</th>
                    <th>Weight</th>
                </tr>
               
               {computers.slice(0,500).map(contact => (<tr>
                  <td>{contact.name}</td>
                  <td>{contact.graphicsName}</td>
                  <td>{contact.hardDiskName}</td>
                  <td>{contact.portName}</td>
                  <td>{contact.powerInfo}</td>
                  <td>{contact.processorName}</td>
                  <td>{contact.ramName}</td>
                  <td>{contact.weightDetail}</td>
                  </tr>))}
                  </tbody>
        </table>
        
        </div>
    )
}

