﻿using HardwareManagement.Application.Features.ComputerManagement.Queries;
using HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputer;
using HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputerList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComputerManagement.Api.Controllers
{
    [ApiController]
    [Route("api/computer")]
    public class ComputerController : ControllerBase
    {
        private IMediator _mediator;

        public ComputerController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<ActionResult<List<ComputerVm>>> GetAllComputers()
        {
            var Computers = await _mediator.Send(new GetComputerListQuery());

            if (Computers == null)
            {
                return NotFound();
            }

            return Ok(Computers);
        }
    }
}
