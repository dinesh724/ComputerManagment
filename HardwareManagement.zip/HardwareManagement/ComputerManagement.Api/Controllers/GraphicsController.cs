﻿using HardwareManagement.Application.Features.Graphics.Queries.GetGraphicsList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComputerManagement.Api.Controllers
{
    [ApiController]
    [Route("api/graphics")]
    public class GraphicsController : ControllerBase
    {
        private IMediator _mediator;

        public GraphicsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<ActionResult<List<GraphicsListVm>>> GetRam()
        {
            var Graphics = await _mediator.Send(new GetGraphicsListQuery());

            if (Graphics == null)
            {
                return NotFound();
            }

            return Ok(Graphics);
        }
    }
}
