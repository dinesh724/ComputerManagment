﻿using HardwareManagement.Application.Features.HardDisks.Queries.GetHardDiskList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComputerManagement.Api.Controllers
{
    [ApiController]
    [Route("api/harddisk")]
    public class HardDiskController : ControllerBase
    {
        private IMediator _mediator;

        public HardDiskController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<ActionResult<List<HardDiskListVm>>> GetRam()
        {
            var hardDisks = await _mediator.Send(new GetHardDiskListQuery());

            if (hardDisks == null)
            {
                return NotFound();
            }

            return Ok(hardDisks);
        }
    }
}
