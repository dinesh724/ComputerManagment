﻿using HardwareManagement.Application.Features.Ports.Queries.GetPortsList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComputerManagement.Api.Controllers
{
    [ApiController]
    [Route("api/ports")]
    public class PortsController : ControllerBase
    {
        private IMediator _mediator;

        public PortsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<ActionResult<List<PortsListVm>>> GetRam()
        {
            var Ports = await _mediator.Send(new GetPortsListQuery());

            if (Ports == null)
            {
                return NotFound();
            }

            return Ok(Ports);
        }
    }
}
