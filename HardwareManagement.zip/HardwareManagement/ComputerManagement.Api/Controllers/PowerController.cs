﻿using HardwareManagement.Application.Features.Powers.Queries.GetPowerList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComputerManagement.Api.Controllers
{
    [ApiController]
    [Route("api/power")]
    public class PowerController : ControllerBase
    {
        private IMediator _mediator;

        public PowerController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<ActionResult<List<PowerVm>>> GetRam()
        {
            var Power = await _mediator.Send(new GetPowerListQuery());

            if (Power == null)
            {
                return NotFound();
            }

            return Ok(Power);
        }
    }
}
