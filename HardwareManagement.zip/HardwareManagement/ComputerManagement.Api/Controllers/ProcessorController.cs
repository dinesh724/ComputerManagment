﻿using HardwareManagement.Application.Features.Processors.Queries.GetProcessorList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComputerManagement.Api.Controllers
{
    [ApiController]
    [Route("api/processor")]
    public class ProcessorController : ControllerBase
    {
        private IMediator _mediator;

        public ProcessorController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<ActionResult<List<ProcessorVm>>> GetRam()
        {
            var Procesors = await _mediator.Send(new GetProcessorListQuery());

            if (Procesors == null)
            {
                return NotFound();
            }

            return Ok(Procesors);
        }
    }
}
