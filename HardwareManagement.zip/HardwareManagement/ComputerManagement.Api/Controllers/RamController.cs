﻿using HardwareManagement.Application.Features.Rams.Queries.GetRamList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComputerManagement.Api.Controllers
{
    [ApiController]
    [Route("api/ram")]
    public class RamController : ControllerBase
    {
        private IMediator _mediator;

        public RamController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<ActionResult<List<RamVm>>> GetRam()
        {
            var Ram = await _mediator.Send(new GetRamListQuery());

            if (Ram == null)
            {
                return NotFound();
            }

            return Ok(Ram);
        }
    }
}
