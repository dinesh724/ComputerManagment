﻿using HardwareManagement.Application.Features.Weights.Queries.GetWeightList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComputerManagement.Api.Controllers
{
    [ApiController]
    [Route("api/weight")]
    public class WeightController : ControllerBase
    {
        private IMediator _mediator;

        public WeightController(IMediator mediator)
        {
            _mediator = mediator;
        }
        [HttpGet]
        public async Task<ActionResult<List<WeightVm>>> GetWeights()
        {
            var Weights = await _mediator.Send(new GetWeightListQuery());

            if (Weights == null)
            {
                return NotFound();
            }

            return Ok(Weights);
        }
    }
}
