﻿using HardwareManagement.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Contracts.Persistence
{
    public interface IManageComputerRepository : IAsyncRepository<Computer>
    {

    }
}
