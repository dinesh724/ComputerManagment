﻿using HardwareManagement.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace HardwareManagement.Application.Contracts.Persistence
{
    public interface IManageComputerViewRepository : IAsyncRepository<ComputerView>
    {
        public Task<List<ComputerView>> GetAllComputers();
    }
}
