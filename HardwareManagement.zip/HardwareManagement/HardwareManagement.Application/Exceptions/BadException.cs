﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Exceptions
{
    public class BadException : ApplicationException
    {
        public BadException(string message) : base(message)
        {

        }
    }
}
