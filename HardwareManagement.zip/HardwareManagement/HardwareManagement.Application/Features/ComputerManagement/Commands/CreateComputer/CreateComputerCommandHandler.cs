﻿using AutoMapper;
using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HardwareManagement.Application.Features.ComputerManagement.Commands.CreateComputer
{
    public class CreateComputerCommandHandler : IRequestHandler<CreateComputerCommand, Guid>
    {
        private IMapper _mapper;
        private IAsyncRepository<Computer> _computerRepository;

        public CreateComputerCommandHandler(IMapper mapper , IAsyncRepository<Computer> computerRepository)
        {
            _mapper = mapper;
            _computerRepository = computerRepository;
        }
        public Task<Guid> Handle(CreateComputerCommand request, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
