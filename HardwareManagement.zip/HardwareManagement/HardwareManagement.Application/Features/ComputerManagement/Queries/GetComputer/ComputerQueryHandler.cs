﻿using AutoMapper;
using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Application.Features.ComputerManagement.Queries;
using HardwareManagement.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputer
{
    public class ComputerQueryHandler : IRequestHandler<GetComputerQuery, ComputerVm>
    {
        private IMapper _mapper;
        private IAsyncRepository<Computer> _computerRepository;

        public ComputerQueryHandler(IMapper mapper, IAsyncRepository<Computer> computerRepository)
        {
            _mapper = mapper;
            _computerRepository = computerRepository;
        }
       
        public async Task<ComputerVm> Handle(GetComputerQuery request, CancellationToken cancellationToken)
        {
            var computer = (await _computerRepository.GetByIdAsync(request.Id));

            return _mapper.Map<ComputerVm>(computer);
        }
    }
}
