﻿using System;

namespace HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputer
{
    public class ComputerVm
    {
        public string Name { get; set; }

        public string GraphicsName { get; set; }

        public string HardDiskName { get; set; }
        public string PortName { get; set; }
        public string PowerName { get; set; }
        public string ProcessorName { get; set; }
        public string RamName { get; set; }
        public string WeightName { get; set; }
    }
}
