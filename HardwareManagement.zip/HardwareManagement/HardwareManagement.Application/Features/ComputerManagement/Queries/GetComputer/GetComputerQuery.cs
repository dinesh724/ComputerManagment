﻿using HardwareManagement.Application.Features.ComputerManagement.Queries;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputer
{
   public class GetComputerQuery : IRequest<ComputerVm>
    {
        public Guid Id { get; set; }
    }
}
