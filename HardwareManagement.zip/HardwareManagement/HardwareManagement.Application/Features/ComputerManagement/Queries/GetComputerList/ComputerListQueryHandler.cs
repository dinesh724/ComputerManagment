﻿using AutoMapper;
using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Application.Features.ComputerManagement.Queries;
using HardwareManagement.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputerList
{
    public class ComputerListQueryHandler : IRequestHandler<GetComputerListQuery, List<ComputerViewVm>>
    {
        private IMapper _mapper;
        private IManageComputerViewRepository _computerViewRepository;

        public ComputerListQueryHandler(IMapper mapper , IManageComputerViewRepository computerViewRepository)
        {
            _mapper = mapper;
            _computerViewRepository = computerViewRepository;
        }

        public async Task<List<ComputerViewVm>> Handle(GetComputerListQuery request, CancellationToken cancellationToken)
        {
            var list = (await _computerViewRepository.GetAllComputers()).OrderBy(x => x.Name);
            return _mapper.Map<List<ComputerViewVm>>(list);
        }
       
    }
}
