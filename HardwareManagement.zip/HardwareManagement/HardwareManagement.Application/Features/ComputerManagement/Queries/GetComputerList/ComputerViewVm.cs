﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputerList
{
    public class ComputerViewVm
    {
        public String Name { get; set; }

        public String GraphicsName { get; set; }

        public String HardDiskName { get; set; }
        public String PortName { get; set; }
        public String PowerInfo { get; set; }
        public String ProcessorName { get; set; }
        public String RamName { get; set; }
        public String WeightDetail { get; set; }
    }
}
