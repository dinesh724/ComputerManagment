﻿using HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputerList;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputerList
{
    public class GetComputerListQuery : IRequest<List<ComputerViewVm>>
    {
    }
}
