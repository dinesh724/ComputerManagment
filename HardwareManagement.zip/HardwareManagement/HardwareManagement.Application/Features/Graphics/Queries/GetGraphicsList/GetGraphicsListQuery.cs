﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.Graphics.Queries.GetGraphicsList
{
   public class GetGraphicsListQuery:  IRequest<List<GraphicsListVm>>
    {
        
    }
}
