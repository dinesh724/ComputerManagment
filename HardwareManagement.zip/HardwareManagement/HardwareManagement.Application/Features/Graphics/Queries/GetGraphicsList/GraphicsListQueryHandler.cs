﻿using AutoMapper;
using HardwareManagement.Application.Contracts.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using HardwareManagement.Domain.Entities;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

namespace HardwareManagement.Application.Features.Graphics.Queries.GetGraphicsList
{
    public class GraphicsListQueryHandler : IRequestHandler<GetGraphicsListQuery, List<GraphicsListVm>>
    {
        private IMapper _mapper;
        private IAsyncRepository<Domain.Entities.Graphic> _graphicsRepository;

        public GraphicsListQueryHandler(IMapper mapper, IAsyncRepository<Graphic> graphicsRepository)
        {
            _mapper = mapper;
            _graphicsRepository = graphicsRepository;
        }

        public async Task<List<GraphicsListVm>> Handle(GetGraphicsListQuery request, CancellationToken cancellationToken)
        {
            var allGraphics = (await _graphicsRepository.ListAllAsync()).OrderBy(x => x.GraphicName);
            return _mapper.Map<List<GraphicsListVm>>(allGraphics);
        }
    }
}
