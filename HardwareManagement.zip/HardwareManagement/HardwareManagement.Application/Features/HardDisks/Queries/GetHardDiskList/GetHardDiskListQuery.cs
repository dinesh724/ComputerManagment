﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.HardDisks.Queries.GetHardDiskList
{
    public class GetHardDiskListQuery : IRequest<List<HardDiskListVm>>
    {
    }
}
