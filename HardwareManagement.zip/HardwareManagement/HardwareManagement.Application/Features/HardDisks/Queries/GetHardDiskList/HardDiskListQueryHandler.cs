﻿using AutoMapper;
using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace HardwareManagement.Application.Features.HardDisks.Queries.GetHardDiskList
{
    public class HardDiskListQueryHandler : IRequestHandler<GetHardDiskListQuery, List<HardDiskListVm>>
    {
        private IMapper _mapper;
        private IAsyncRepository<HardDisk> _hardDiskRepository;

        public HardDiskListQueryHandler(IMapper mapper, IAsyncRepository<HardDisk> hardDiskRepository)
        {
            _mapper = mapper;
            _hardDiskRepository = hardDiskRepository;
        }
        public async Task<List<HardDiskListVm>> Handle(GetHardDiskListQuery request, CancellationToken cancellationToken)
        {
            var allHardDisks = (await _hardDiskRepository.ListAllAsync()).OrderBy(x => x.HardDiskName);
            return _mapper.Map<List<HardDiskListVm>>(allHardDisks);
        }
    }
}
