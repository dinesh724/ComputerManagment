﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.HardDisks.Queries.GetHardDiskList
{
    public class HardDiskListVm
    {
        public string HardDiskName { get; set; }
    }
}
