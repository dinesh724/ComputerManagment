﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.Ports.Queries.GetPortsList
{
    public class GetPortsListQuery : IRequest<List<PortsListVm>>
    {

    }
}
