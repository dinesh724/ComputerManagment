﻿using AutoMapper;
using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HardwareManagement.Application.Features.Ports.Queries.GetPortsList
{
    public class PortListQueryHandler : IRequestHandler<GetPortsListQuery, List<PortsListVm>>
    {
        private IMapper _mapper;
        private IAsyncRepository<Port> _portRepository;

        public PortListQueryHandler(IMapper mapper , IAsyncRepository<Port> portRepository)
        {
            _mapper = mapper;
            _portRepository = portRepository;
        }
        public async Task<List<PortsListVm>> Handle(GetPortsListQuery request, CancellationToken cancellationToken)
        {
            var getAllPorts = (await _portRepository.ListAllAsync()).OrderBy(x => x.PortName);
            return _mapper.Map<List<PortsListVm>>(getAllPorts);
        }
    }   
}
