﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.Ports.Queries.GetPortsList
{
    public class PortsListVm
    {
        public string PortName { get; set; }
    }
}
