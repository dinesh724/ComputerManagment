﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.Powers.Queries.GetPowerList
{
   public class GetPowerListQuery : IRequest<List<PowerVm>>
    {
    }
}
