﻿using AutoMapper;
using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HardwareManagement.Application.Features.Powers.Queries.GetPowerList
{
    public class PowerListQueryHanlder : IRequestHandler<GetPowerListQuery, List<PowerVm>>
    {
        private IMapper _mapper;
        private IAsyncRepository<Power> _powerRepository;

        public PowerListQueryHanlder(IMapper mapper , IAsyncRepository<Power> powerRepository)
        {
            _mapper = mapper;
            _powerRepository = powerRepository;
        }
        public async Task<List<PowerVm>> Handle(GetPowerListQuery request, CancellationToken cancellationToken)
        {
            var allPowers = (await _powerRepository.ListAllAsync()).OrderBy(x => x.PowerInfo);
            return _mapper.Map<List<PowerVm>>(allPowers);
        }
    }
}
