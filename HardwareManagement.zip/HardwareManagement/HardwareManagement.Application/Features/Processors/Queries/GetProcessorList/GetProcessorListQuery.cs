﻿using HardwareManagement.Application.Features.Processors.Queries.GetProcessorList;
using MediatR;
using System.Collections.Generic;

namespace HardwareManagement.Application.Features.Processors.Queries.GetProcessorList
{
    public class GetProcessorListQuery : IRequest<List<ProcessorVm>>
    {
    }
}
