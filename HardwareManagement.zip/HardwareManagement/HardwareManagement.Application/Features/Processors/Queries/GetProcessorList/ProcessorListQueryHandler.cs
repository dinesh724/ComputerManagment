﻿using AutoMapper;
using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Application.Features.Processors.Queries.GetProcessorList;
using HardwareManagement.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HardwareManagement.Application.Features.Processors.Queries.GetProcessorList
{
    public class ProcessorListQueryHandler : IRequestHandler<GetProcessorListQuery, List<ProcessorVm>>
    {
        private IMapper _mapper;
        private IAsyncRepository<Processor> _processorRepository;

        public ProcessorListQueryHandler(IMapper mapper , IAsyncRepository<Processor> processorRepository)
        {
            _mapper = mapper;
            _processorRepository = processorRepository;
        }
        public async Task<List<ProcessorVm>> Handle(GetProcessorListQuery request, CancellationToken cancellationToken)
        {
            var allProcessors = (await _processorRepository.ListAllAsync()).OrderBy(x => x.ProcessorName);

            return _mapper.Map <List<ProcessorVm>>(allProcessors);
        }
    }
}
