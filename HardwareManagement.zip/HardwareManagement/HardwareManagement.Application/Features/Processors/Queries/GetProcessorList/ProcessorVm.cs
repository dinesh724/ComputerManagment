﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.Processors.Queries.GetProcessorList
{
    public class ProcessorVm
    {
        public string ProcessorName { get; set; }
    }
}
