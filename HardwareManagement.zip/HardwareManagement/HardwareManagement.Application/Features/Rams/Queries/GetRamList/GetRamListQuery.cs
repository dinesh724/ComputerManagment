﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.Rams.Queries.GetRamList
{
    public class GetRamListQuery : IRequest<List<RamVm>>
    {
    }
}
