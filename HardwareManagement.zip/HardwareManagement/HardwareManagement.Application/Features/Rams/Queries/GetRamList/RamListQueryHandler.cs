﻿using AutoMapper;
using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HardwareManagement.Application.Features.Rams.Queries.GetRamList
{
    public class RamListQueryHandler : IRequestHandler<GetRamListQuery, List<RamVm>>
    {
        private IMapper _mapper;
        private IAsyncRepository<Ram> _ramRepository;

        public RamListQueryHandler(IMapper mapper, IAsyncRepository<Ram> ramRepository)
        {
            _mapper = mapper;
            _ramRepository = ramRepository;
        }
        public async Task<List<RamVm>> Handle(GetRamListQuery request, CancellationToken cancellationToken)
        {
            var allRams = (await _ramRepository.ListAllAsync()).OrderBy(x => x.RamName);

            return _mapper.Map<List<RamVm>>(allRams);
        }
    }
}
