﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.Rams.Queries.GetRamList
{
    public class RamVm
    {
        public string RamName
        {
            get; set;
        }
    }
}
