﻿using AutoMapper;
using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HardwareManagement.Application.Features.Weights.Queries.GetWeightList
{
    public class WeightListQueryHandler : IRequestHandler<GetWeightListQuery, List<WeightVm>>
    {
        private IMapper _mapper;
        private IAsyncRepository<Weight> _weightRepository;

        public WeightListQueryHandler( IMapper mapper , IAsyncRepository<Weight> weightRepository)
        {
            _mapper = mapper;
            _weightRepository = weightRepository;
        }
        public async Task<List<WeightVm>> Handle(GetWeightListQuery request, CancellationToken cancellationToken)
        {
            var allWeights = (await _weightRepository.ListAllAsync()).OrderBy(x => x.WeightDetail);

            return _mapper.Map<List<WeightVm>>(allWeights);
        }
    }
}
