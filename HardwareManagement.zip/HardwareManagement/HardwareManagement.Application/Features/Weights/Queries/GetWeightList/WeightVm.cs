﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Application.Features.Weights.Queries.GetWeightList
{
   public class WeightVm
    {
        public string WeightDetail
        {
            get; set;
        }
    }
}
