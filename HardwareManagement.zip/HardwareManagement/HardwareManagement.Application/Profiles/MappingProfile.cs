﻿using AutoMapper;
using HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputer;
using HardwareManagement.Application.Features.ComputerManagement.Queries.GetComputerList;
using HardwareManagement.Application.Features.Graphics.Queries.GetGraphicsList;
using HardwareManagement.Application.Features.HardDisks.Queries.GetHardDiskList;
using HardwareManagement.Application.Features.Ports.Queries.GetPortsList;
using HardwareManagement.Application.Features.Powers.Queries.GetPowerList;
using HardwareManagement.Application.Features.Processors.Queries.GetProcessorList;
using HardwareManagement.Application.Features.Rams.Queries.GetRamList;
using HardwareManagement.Application.Features.Weights.Queries.GetWeightList;
using HardwareManagement.Domain.Entities;

namespace HardwareManagement.Application.Profiles
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Computer, ComputerVm>().ReverseMap();
            CreateMap<ComputerView, ComputerViewVm>().ReverseMap();
            CreateMap<Graphic, GraphicsListVm>().ReverseMap();
            CreateMap<Weight, WeightVm>().ReverseMap();
            CreateMap<Ram, RamVm>().ReverseMap();
            CreateMap<Processor, ProcessorVm>().ReverseMap();
            CreateMap<Power, PowerVm>().ReverseMap();
            CreateMap<Port, PortsListVm>().ReverseMap();
            CreateMap<HardDisk, HardDiskListVm>().ReverseMap();
        }
    }
}
