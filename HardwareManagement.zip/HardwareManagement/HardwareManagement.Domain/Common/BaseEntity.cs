﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Domain.Common
{
    public class BaseEntity
    {
        public DateTime DateCreated { get; set; }

        public bool Display { get; set; }
    }
}
