﻿using HardwareManagement.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Domain.Entities
{
    public class Computer : BaseEntity
    {
        public Guid ComputerId { get; set; }

        public String Name { get; set; }

        public Guid GraphicsId { get; set; }

        public Guid HardDiskId { get; set; }
        public Guid PortId { get; set; }
        public Guid PowerId { get; set; }
        public Guid ProcessorId { get; set; }
        public Guid RamId { get; set; }
        public Guid WeightId { get; set; }
      
    }
}
