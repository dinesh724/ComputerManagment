﻿using HardwareManagement.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Domain.Entities
{
   public class Graphic :BaseEntity
    {
        public Guid GraphicId { get; set; }

        public string GraphicName { get; set; }
    }
}
