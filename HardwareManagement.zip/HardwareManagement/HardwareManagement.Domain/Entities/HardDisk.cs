﻿using HardwareManagement.Domain.Common;
using System;

namespace HardwareManagement.Domain.Entities
{
    public class HardDisk : BaseEntity
    {
        public Guid HardDiskId { get; set; }

        public string HardDiskName { get; set; }
    }
}
