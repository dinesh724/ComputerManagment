﻿using HardwareManagement.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Domain.Entities
{
    public class Port : BaseEntity
    {
        public Guid PortId { get; set; }

        public string PortName { get; set; }
    }
}
