﻿using HardwareManagement.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Domain.Entities
{
    public class Power : BaseEntity
    {
        public Guid PowerId { get; set; }

        public string PowerInfo { get; set; }
    }
}
