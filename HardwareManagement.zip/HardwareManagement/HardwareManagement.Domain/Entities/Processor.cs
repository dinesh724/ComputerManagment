﻿using HardwareManagement.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;
namespace HardwareManagement.Domain.Entities
{
    public class Processor : BaseEntity 
    {
        public Guid ProcessorId { get; set; }

        public string ProcessorName { get; set; }
    }
}
