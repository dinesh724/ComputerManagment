﻿using HardwareManagement.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;
namespace HardwareManagement.Domain.Entities
{
    public class Ram : BaseEntity
    {
        public Guid RamId
        {
            get; set;
        }
        public string RamName
        {
            get; set;
        }
     }
}
