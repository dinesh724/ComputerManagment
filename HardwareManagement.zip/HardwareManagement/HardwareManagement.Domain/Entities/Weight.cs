﻿using HardwareManagement.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;
namespace HardwareManagement.Domain.Entities
{
    public class Weight : BaseEntity
    {
        public Guid WeightId
        {
            get; set;
        }
        public string WeightDetail
        {
            get; set;
        }
     }
}
