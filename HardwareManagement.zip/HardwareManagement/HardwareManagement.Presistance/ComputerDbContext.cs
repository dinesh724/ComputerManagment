﻿using HardwareManagement.Domain.Common;
using HardwareManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HardwareManagement.Presistance
{
    public class ComputerDbContext : DbContext
    {
        public ComputerDbContext(DbContextOptions<ComputerDbContext> options)
           : base(options)
        {

        }
        public DbSet<Computer> Computer { get; set; }

        public DbSet<ComputerView> ComputerView { get; set; }
        public DbSet<Graphic> Graphic { get; set; }
        public DbSet<HardDisk> HardDisk { get; set; }
        public DbSet<Port> Port { get; set; }
        public DbSet<Power> Power { get; set; }
        public DbSet<Processor> Processor { get; set; }

        public DbSet<Ram> Ram { get; set; }
        public DbSet<Weight> Weight { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfigurationsFromAssembly(typeof(ComputerDbContext).Assembly);

            modelBuilder
           .Entity<ComputerView>(c =>
           {
               c.HasNoKey();
               c.ToView("vw_Computer");
           });

            var GraphicGuid = Guid.Parse("5d8bf118-67ef-48f5-b8b5-d596d87375e3");

            modelBuilder.Entity<Graphic>().HasData(
             new Graphic
             {
                GraphicId = GraphicGuid,
                GraphicName = "",
                Display = true
             });

            var HardDiskGuid = Guid.Parse("e62076c1-c888-4e58-9109-bb37ffae9899");

            modelBuilder.Entity<HardDisk>().HasData(
             new HardDisk
             {
                 HardDiskId = GraphicGuid,
                 HardDiskName = "",
                 Display = true
             });

            var PortGuid = Guid.Parse("a9735eb5-5244-4b1c-8f4c-e968ab4a7176");

            modelBuilder.Entity<Port>().HasData(
             new Port
             {
                 PortId = GraphicGuid,
                 PortName = "",
                 Display = true
             });

            var PowerGuid = Guid.Parse("0e992f87-d183-48b6-9081-06677d8c7063");

            modelBuilder.Entity<Power>().HasData(
             new Power
             {
                 PowerId = GraphicGuid,
                 PowerInfo = "",
                 Display = true
             });

            var ProcessorGuid = Guid.Parse("a6cc573d-724c-4b42-98b3-713ba3398f3d");

            modelBuilder.Entity<Processor>().HasData(
             new Processor
             {
                 ProcessorId = GraphicGuid,
                 ProcessorName = "",
                 Display = true
             });

            var RamGuid = Guid.Parse("2db3fcce-e0c4-410d-8944-953807b74b7b");

            modelBuilder.Entity<Ram>().HasData(
             new Ram
             {
                 RamId = GraphicGuid,
                 RamName = "",
                 Display = true
             });

            var WeightGuid = Guid.Parse("9eb0e584-8a91-4eec-9a65-e57ffe9cae38");

            modelBuilder.Entity<Weight>().HasData(
             new Weight
             {
                 WeightId = GraphicGuid,
                 WeightDetail = "",
                 Display = true
             });

            var ComputerGuid = Guid.Parse("9eb0e584-8a91-4eec-9a65-e57ffe9cae38");

            modelBuilder.Entity<Computer>().HasData(
             new Computer
             {
                 ComputerId = ComputerGuid,
                 Display = true,
                 Name = "First Computer",
                 GraphicsId=GraphicGuid,
                 HardDiskId=HardDiskGuid,
                 PortId=PortGuid,
                 ProcessorId=ProcessorGuid,
                 RamId=RamGuid,
                 WeightId=WeightGuid
                 
             });
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            foreach (var entry in ChangeTracker.Entries<BaseEntity>())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.Entity.DateCreated = DateTime.Now;
                        entry.Entity.Display = true;
                        break;
                    
                }
            }
            return base.SaveChangesAsync(cancellationToken);
        }

    }
}
