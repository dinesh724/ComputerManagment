﻿using HardwareManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HardwareManagement.Presistance.Configuration
{
    public class ComputerConfiguration : IEntityTypeConfiguration<Computer>
    {

        public void Configure(EntityTypeBuilder<Computer> builder)
        {
            builder.Property(p => p.Name)
             .IsRequired();
            builder.Property(p => p.GraphicsId)
               .IsRequired();
            builder.Property(p => p.HardDiskId)
               .IsRequired();
            builder.Property(p => p.PortId)
               .IsRequired();
            builder.Property(p => p.PowerId)
             .IsRequired();
            builder.Property(p => p.ProcessorId)
             .IsRequired();
            builder.Property(p => p.RamId)
             .IsRequired();
            builder.Property(p => p.WeightId)
             .IsRequired();
        }
    }
}
