﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace HardwareManagement.Presistance.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Computer",
                columns: table => new
                {
                    ComputerId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    GraphicsId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    HardDiskId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PortId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PowerId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProcessorId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RamId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WeightId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Display = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Computer", x => x.ComputerId);
                });

            migrationBuilder.CreateTable(
                name: "Graphic",
                columns: table => new
                {
                    GraphicId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    GraphicName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Display = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Graphic", x => x.GraphicId);
                });

            migrationBuilder.CreateTable(
                name: "HardDisk",
                columns: table => new
                {
                    HardDiskId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    HardDiskName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Display = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HardDisk", x => x.HardDiskId);
                });

            migrationBuilder.CreateTable(
                name: "Port",
                columns: table => new
                {
                    PortId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PortName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Display = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Port", x => x.PortId);
                });

            migrationBuilder.CreateTable(
                name: "Power",
                columns: table => new
                {
                    PowerId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PowerInfo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Display = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Power", x => x.PowerId);
                });

            migrationBuilder.CreateTable(
                name: "Processor",
                columns: table => new
                {
                    ProcessorId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProcessorName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Display = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Processor", x => x.ProcessorId);
                });

            migrationBuilder.CreateTable(
                name: "Ram",
                columns: table => new
                {
                    RamId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RamName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Display = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ram", x => x.RamId);
                });

            migrationBuilder.CreateTable(
                name: "Weight",
                columns: table => new
                {
                    WeightId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WeightDetail = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Display = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Weight", x => x.WeightId);
                });

            migrationBuilder.InsertData(
                table: "Computer",
                columns: new[] { "ComputerId", "DateCreated", "Display", "GraphicsId", "HardDiskId", "Name", "PortId", "PowerId", "ProcessorId", "RamId", "WeightId" },
                values: new object[] { new Guid("9eb0e584-8a91-4eec-9a65-e57ffe9cae38"), new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, new Guid("5d8bf118-67ef-48f5-b8b5-d596d87375e3"), new Guid("e62076c1-c888-4e58-9109-bb37ffae9899"), "First Computer", new Guid("a9735eb5-5244-4b1c-8f4c-e968ab4a7176"), new Guid("00000000-0000-0000-0000-000000000000"), new Guid("a6cc573d-724c-4b42-98b3-713ba3398f3d"), new Guid("2db3fcce-e0c4-410d-8944-953807b74b7b"), new Guid("9eb0e584-8a91-4eec-9a65-e57ffe9cae38") });

            migrationBuilder.InsertData(
                table: "Graphic",
                columns: new[] { "GraphicId", "DateCreated", "Display", "GraphicName" },
                values: new object[] { new Guid("5d8bf118-67ef-48f5-b8b5-d596d87375e3"), new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "" });

            migrationBuilder.InsertData(
                table: "HardDisk",
                columns: new[] { "HardDiskId", "DateCreated", "Display", "HardDiskName" },
                values: new object[] { new Guid("5d8bf118-67ef-48f5-b8b5-d596d87375e3"), new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "" });

            migrationBuilder.InsertData(
                table: "Port",
                columns: new[] { "PortId", "DateCreated", "Display", "PortName" },
                values: new object[] { new Guid("5d8bf118-67ef-48f5-b8b5-d596d87375e3"), new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "" });

            migrationBuilder.InsertData(
                table: "Power",
                columns: new[] { "PowerId", "DateCreated", "Display", "PowerInfo" },
                values: new object[] { new Guid("5d8bf118-67ef-48f5-b8b5-d596d87375e3"), new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "" });

            migrationBuilder.InsertData(
                table: "Processor",
                columns: new[] { "ProcessorId", "DateCreated", "Display", "ProcessorName" },
                values: new object[] { new Guid("5d8bf118-67ef-48f5-b8b5-d596d87375e3"), new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "" });

            migrationBuilder.InsertData(
                table: "Ram",
                columns: new[] { "RamId", "DateCreated", "Display", "RamName" },
                values: new object[] { new Guid("5d8bf118-67ef-48f5-b8b5-d596d87375e3"), new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "" });

            migrationBuilder.InsertData(
                table: "Weight",
                columns: new[] { "WeightId", "DateCreated", "Display", "WeightDetail" },
                values: new object[] { new Guid("5d8bf118-67ef-48f5-b8b5-d596d87375e3"), new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "" });
           

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Computer");

            migrationBuilder.DropTable(
                name: "Graphic");

            migrationBuilder.DropTable(
                name: "HardDisk");

            migrationBuilder.DropTable(
                name: "Port");

            migrationBuilder.DropTable(
                name: "Power");

            migrationBuilder.DropTable(
                name: "Processor");

            migrationBuilder.DropTable(
                name: "Ram");

            migrationBuilder.DropTable(
                name: "Weight");
        }
    }
}
