﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HardwareManagement.Presistance.Migrations
{
    public partial class ComputerViews : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var sql = @"
            CREATE VIEW [dbo].[vw_Computer]
AS
SELECT TOP (100) PERCENT dbo.Computer.Name, dbo.HardDisk.HardDiskName, dbo.Port.PortName, dbo.Power.PowerInfo, dbo.Processor.ProcessorName, dbo.Ram.RamName, dbo.Weight.WeightDetail, dbo.Graphic.GraphicName
FROM     dbo.Computer INNER JOIN
                  dbo.HardDisk ON dbo.Computer.HardDiskId = dbo.HardDisk.HardDiskId LEFT OUTER JOIN
                  dbo.Port ON dbo.Computer.PortId = dbo.Port.PortId LEFT OUTER JOIN
                  dbo.Power ON dbo.Computer.PowerId = dbo.Power.PowerId LEFT OUTER JOIN
                  dbo.Processor ON dbo.Computer.ProcessorId = dbo.Processor.ProcessorId LEFT OUTER JOIN
                  dbo.Ram ON dbo.Computer.RamId = dbo.Ram.RamId LEFT OUTER JOIN
                  dbo.Weight ON dbo.Computer.WeightId = dbo.Weight.WeightId LEFT OUTER JOIN
                  dbo.Graphic ON dbo.Computer.GraphicsId = dbo.Graphic.GraphicId";

            migrationBuilder.Sql(sql);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"DROP VIEW vw_Computer");
        }
    }
}
