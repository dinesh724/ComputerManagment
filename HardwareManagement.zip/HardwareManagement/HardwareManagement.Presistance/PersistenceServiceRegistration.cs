﻿using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Presistance.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace HardwareManagement.Presistance
{
    public static class PersistenceServiceRegistration
    {
        public static IServiceCollection AddPersistanceServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<ComputerDbContext>(options =>
            options.UseSqlServer(configuration.GetConnectionString("GetContactManagementConnectionString")));

            services.AddScoped(typeof(IAsyncRepository<>), typeof(BaseRepository<>));

            services.AddScoped(typeof(IManageComputerRepository), typeof(ComputerRepository));
            services.AddScoped(typeof(IManageComputerViewRepository), typeof(ComputerViewRepository));
            return services;
        }
    }
}
