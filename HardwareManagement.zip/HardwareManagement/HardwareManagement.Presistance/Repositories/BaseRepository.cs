﻿using HardwareManagement.Application.Contracts.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HardwareManagement.Presistance.Repositories
{
    public class BaseRepository<T> : IAsyncRepository<T> where T : class
    {
        protected readonly ComputerDbContext _computerDbContext;

        public BaseRepository(ComputerDbContext computerDbContext)
        {
            _computerDbContext = computerDbContext;
        }

        public async Task<T> AddAsync(T entity)
        {
            await _computerDbContext.Set<T>().AddAsync(entity);
            await _computerDbContext.SaveChangesAsync();

            return entity;
        }



        public async Task<T> GetByIdAsync(Guid id)
        {
            return await _computerDbContext.Set<T>().FindAsync(id);
        }

        public async Task<IReadOnlyList<T>> ListAllAsync()
        {
            return await _computerDbContext.Set<T>().ToListAsync();
        }

        public async Task UpdateAsync(T entity)
        {
            _computerDbContext.Entry(entity).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            await _computerDbContext.SaveChangesAsync();
        }



        public async Task DeleteAsync(T entity)
        {
            _computerDbContext.Set<T>().Remove(entity);
            await _computerDbContext.SaveChangesAsync();
        }


    }
}
