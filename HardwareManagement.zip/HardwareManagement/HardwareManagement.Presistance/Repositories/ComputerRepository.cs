﻿using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace HardwareManagement.Presistance.Repositories
{
    public class ComputerRepository : BaseRepository<Computer>, IManageComputerRepository
    {
        public ComputerRepository(ComputerDbContext dbContext) : base(dbContext)
        {

        }
    }
}
