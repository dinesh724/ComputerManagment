﻿using HardwareManagement.Application.Contracts.Persistence;
using HardwareManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace HardwareManagement.Presistance.Repositories
{
    public class ComputerViewRepository : BaseRepository<ComputerView>, IManageComputerViewRepository
    {
        public ComputerViewRepository(ComputerDbContext dbContext) : base(dbContext)
        {

        }

        public async Task<List<ComputerView>> GetAllComputers()
        {
            return await _computerDbContext.ComputerView.ToListAsync();
        }
    }
}
